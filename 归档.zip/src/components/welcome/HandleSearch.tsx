import React, {useEffect, useState} from 'react';
import { Input, Space, Card } from 'antd';
import ProTable from '@ant-design/pro-table';
import {ProColumns} from "@ant-design/pro-components";
import {FormattedMessage} from "@@/exports";
import {request} from "@umijs/max";
import {val} from "@umijs/utils/compiled/cheerio/lib/api/attributes";

const HomeSearch = () => {
  const [searchValue, setSearchValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [table1Data, setTable1Data] = useState([]);
  const [table2Data, setTable2Data] = useState([]);
  const [table3Data, setTable3Data] = useState([]);

  const columns1: ProColumns<API.Risk>[] = [
    {
      title: (
        <FormattedMessage
          id="pages.risk.id"
          defaultMessage="风险Id"
        />
      ),
      dataIndex: 'id',
      tip: '风险编号',
    },
    {
      title: <FormattedMessage id="pages.risk.site" defaultMessage="场所部位" />,
      dataIndex: 'site',
      valueType: 'textarea',
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.equipment"
          defaultMessage="装备以及工具"
        />
      ),
      dataIndex: 'equip',
      sorter: true,
      hideInForm: true,

    },
    {
      title: <FormattedMessage id="pages.risk.energySource" defaultMessage="能量源" />,
      dataIndex: 'energySource',
      hideInForm: true,
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.describe"
          defaultMessage="风险描述"
        />
      ),
      sorter: true,
      dataIndex: 'riskDescribe',
    },
    {
      title: <FormattedMessage id="pages.risk.accident" defaultMessage="事故类型" />,
      dataIndex: 'accidentType',
    },
    {
      title: "L",
      dataIndex: 'l',
    },
    {
      title: "S",
      dataIndex: 's',
    },
    {
      title: "R",
      dataIndex: 'r',
      render: (text, record) => {
        let color;
        if(record.riskLevel == '三级'){
          color = 'yellow';
        }else if(record.riskLevel == '二级'){
          color = 'orange';
        }else if(record.riskLevel == '一级'){
          color = 'red';
        }else if(record.riskLevel == '四级'){
          color = 'blue';
        }
        return {
          children: text,
          props: {
            style: {
              backgroundColor: color,
            },
          },
        };
      },
    },
    {
      title: "风险等级",
      dataIndex: 'riskLevel',
    },
    {
      title: "工程技术措施",
      dataIndex: 'engTecMeasure',
    },
    {
      title: "安全管理措施",
      dataIndex: 'secuManageMeasure',
    },
    {
      title: "个人培训措施",
      dataIndex: 'personalTrainingMea',
    }
    ,
    {
      title: "个人防护措施",
      dataIndex: 'indiviProtectMeasure',
    },
    {
      title: "应急处理措施",
      dataIndex: 'emergencyMeasure',
    },
    {
      title: "责任部门",
      dataIndex: 'responDepartment',
    },
    {
      title: "责任人",
      dataIndex: 'reponPerson',
    },
    {
      title: "案例链接",
      dataIndex: 'link',
      width: "100px",
      render: (text, record) => {

        if (text) {
          const urls = text.split('\n');
          const urlElements = urls.map((url, index) => (
            <div key={index}>
              <a href={url} style={{width:"100px",wordBreak: 'break-all'}}>{url}</a>
            </div>
          ));

          return {
            children: urlElements,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        } else {
          return {
            children: null,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        }
      },
    },
    {
      title: "案例描述",
      dataIndex: 'caseDescribe',
      ellipsis: true,
    }
  ];

  const columns2: ProColumns<API.Risk>[] = [
    {
      title: (
        <FormattedMessage
          id="pages.risk.id"
          defaultMessage="风险Id"
        />
      ),
      dataIndex: 'id',
      tip: '风险编号',
    },
    {
      title: <FormattedMessage id="pages.risk.site" defaultMessage="场所部位" />,
      dataIndex: 'location',
      valueType: 'textarea',
    },
    {
      title: <FormattedMessage id="pages.risk.site" defaultMessage="管理活动类型" />,
      dataIndex: 'manageActivityTypes',
      valueType: 'textarea',
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.equipment"
          defaultMessage="装备以及工具"
        />
      ),
      dataIndex: 'equipmentAndTools',
      sorter: true,
      hideInForm: true,
      // renderText: (val: string) =>
      //   `${val}${intl.formatMessage({
      //     id: 'pages.risk.equip',
      //     defaultMessage: '  ',
      //   })}`,
    },
    {
      title: <FormattedMessage id="pages.risk.energySource" defaultMessage="能量源" />,
      dataIndex: 'energySource',
      hideInForm: true,
      // valueEnum: {
      //   0: {
      //     text: (
      //       <FormattedMessage
      //         id="pages.searchTable.nameStatus.default"
      //         defaultMessage="Shut down"
      //       />
      //     ),
      //     status: 'Default',
      //   },
      //   1: {
      //     text: (
      //       <FormattedMessage id="pages.searchTable.nameStatus.running" defaultMessage="Running" />
      //     ),
      //     status: 'Processing',
      //   },
      //   2: {
      //     text: (
      //       <FormattedMessage id="pages.searchTable.nameStatus.online" defaultMessage="Online" />
      //     ),
      //     status: 'Success',
      //   },
      //   3: {
      //     text: (
      //       <FormattedMessage
      //         id="pages.searchTable.nameStatus.abnormal"
      //         defaultMessage="Abnormal"
      //       />
      //     ),
      //     status: 'Error',
      //   },
      // },
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.describe"
          defaultMessage="风险描述"
        />
      ),
      sorter: true,
      dataIndex: 'riskDescription',
      //valueType: 'dateTime',
      // renderFormItem: (item, { defaultRender, ...rest }, form) => {
      //   const status = form.getFieldValue('status');
      //   if (`${status}` === '0') {
      //     return false;
      //   }
      //   if (`${status}` === '3') {
      //     return (
      //       <Input
      //         {...rest}
      //         placeholder={intl.formatMessage({
      //           id: 'pages.searchTable.exception',
      //           defaultMessage: 'Please enter the reason for the exception!',
      //         })}
      //       />
      //     );
      //   }
      //   return defaultRender(item);
      // },
    },
    {
      title: <FormattedMessage id="pages.risk.accident" defaultMessage="事故类型" />,
      dataIndex: 'accidentType',
      //valueType: 'option',
      // render: (_, record) => [
      //   <a
      //     key="config"
      //     onClick={() => {
      //       handleUpdateModalOpen(true);
      //       setCurrentRow(record);
      //     }}
      //   >
      //     <FormattedMessage id="pages.searchTable.config" defaultMessage="Configuration" />
      //   </a>,
      //   <a key="subscribeAlert" href="https://procomponents.ant.design/">
      //     <FormattedMessage
      //       id="pages.searchTable.subscribeAlert"
      //       defaultMessage="Subscribe to alerts"
      //     />
      //   </a>,
      // ],
    },
    {
      title: "L",
      dataIndex: 'l',
    },
    {
      title: "E",
      dataIndex: 'e',
    },{
      title: "C",
      dataIndex: 'c',
    },
    {
      title: "D",
      dataIndex: 'd',
      render: (text, record) => {
        let color;
        if(record.riskLevel == '三级'){
          color = 'yellow';
        }else if(record.riskLevel == '二级'){
          color = 'orange';
        }else if(record.riskLevel == '一级'){
          color = 'red';
        }else if(record.riskLevel == '四级'){
          color = 'blue';
        }
        return {
          children: text,
          props: {
            style: {
              backgroundColor: color,
            },
          },
        };
      },
    },
    {
      title: "风险等级",
      dataIndex: 'riskLevel',
    },
    {
      title: "工程技术措施",
      dataIndex: 'engineeringTechnicalMeasures',
    },
    {
      title: "安全管理措施",
      dataIndex: 'safetyManagementMeasures',
    },
    {
      title: "个人培训措施",
      dataIndex: 'personnelTrainingMeasures',
    }
    ,
    {
      title: "个人防护措施",
      dataIndex: 'individualProtection',
    },
    {
      title: "应急处理措施",
      dataIndex: 'emergencyResponseMeasures',
    },
    {
      title: "责任部门",
      dataIndex: 'responsibleDepartment',
    },
    {
      title: "责任人",
      dataIndex: 'personLiable',
    },
    {
      title: "案例链接",
      dataIndex: 'link',
      width: "100px",
      render: (text, record) => {

        if (text) {
          const urls = text.split('\n');
          const urlElements = urls.map((url, index) => (
            <div key={index}>
              <a href={url} style={{width:"100px",wordBreak: 'break-all'}}>{url}</a>
            </div>
          ));

          return {
            children: urlElements,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        } else {
          return {
            children: null,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        }
      },
    },
    {
      title: "案例描述",
      dataIndex: 'caseDescribe',
      ellipsis: true,
    }
  ];

  const columns3: ProColumns<API.Risk>[] = [
    {
      title: (
        <FormattedMessage
          id="pages.risk.id"
          defaultMessage="风险Id"
        />
      ),
      dataIndex: 'id',
      tip: '风险编号',
    },
    {
      title: <FormattedMessage id="pages.risk.site" defaultMessage="管理类型" />,
      dataIndex: 'management_type',
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.risk_unit"
          defaultMessage="风险单元"
        />
      ),
      dataIndex: 'risk_unit',
      sorter: true,
      hideInForm: true,
      // renderText: (val: string) =>
      //   `${val}${intl.formatMessage({
      //     id: 'pages.risk.equip',
      //     defaultMessage: '  ',
      //   })}`,
    },
    {
      title: <FormattedMessage id="pages.risk.risk_description" defaultMessage="风险描述" />,
      dataIndex: 'risk_description',
      // valueEnum: {
      //   0: {
      //     text: (
      //       <FormattedMessage
      //         id="pages.searchTable.nameStatus.default"
      //         defaultMessage="Shut down"
      //       />
      //     ),
      //     status: 'Default',
      //   },
      //   1: {
      //     text: (
      //       <FormattedMessage id="pages.searchTable.nameStatus.running" defaultMessage="Running" />
      //     ),
      //     status: 'Processing',
      //   },
      //   2: {
      //     text: (
      //       <FormattedMessage id="pages.searchTable.nameStatus.online" defaultMessage="Online" />
      //     ),
      //     status: 'Success',
      //   },
      //   3: {
      //     text: (
      //       <FormattedMessage
      //         id="pages.searchTable.nameStatus.abnormal"
      //         defaultMessage="Abnormal"
      //       />
      //     ),
      //     status: 'Error',
      //   },
      // },
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.risk_consequences"
          defaultMessage="风险后果"
        />
      ),
      sorter: true,
      dataIndex: 'risk_consequences',
      //valueType: 'dateTime',
      // renderFormItem: (item, { defaultRender, ...rest }, form) => {
      //   const status = form.getFieldValue('status');
      //   if (`${status}` === '0') {
      //     return false;
      //   }
      //   if (`${status}` === '3') {
      //     return (
      //       <Input
      //         {...rest}
      //         placeholder={intl.formatMessage({
      //           id: 'pages.searchTable.exception',
      //           defaultMessage: 'Please enter the reason for the exception!',
      //         })}
      //       />
      //     );
      //   }
      //   return defaultRender(item);
      // },
    },
    {
      title: "L",
      dataIndex: 'l',
    },
    {
      title: "S",
      dataIndex: 's',
    },
    {
      title: "R",
      dataIndex: 'r',
      render: (text, record) => {
        let color;
        if(record.risk_level == '三级'){
          color = 'yellow';
        }else if(record.risk_level == '二级'){
          color = 'orange';
        }else if(record.risk_level == '一级'){
          color = 'red';
        }else if(record.risk_level == '四级'){
          color = 'blue';
        }
        return {
          children: text,
          props: {
            style: {
              backgroundColor: color,
            },
          },
        };
      },
    },
    {
      title: "风险等级",
      dataIndex: 'risk_level',
    },
    {
      title: "工程技术措施",
      dataIndex: 'engineering_measures',
    },
    {
      title: "安全管理措施",
      dataIndex: 'safety_measures',
    },
    {
      title: "个人培训措施",
      dataIndex: 'training_measures',
    }
    ,
    {
      title: "个人防护措施",
      dataIndex: 'individual_protection',
    },
    {
      title: "应急处理措施",
      dataIndex: 'emergency_measures',
    },
    {
      title: "责任部门",
      dataIndex: 'responsible_department',
    },
    {
      title: "责任人",
      dataIndex: 'person_liable',
    },
    {
      title: "案例链接",
      dataIndex: 'link',
      width: "100px",
      render: (text, record) => {

        if (text) {
          const urls = text.split('\n');
          const urlElements = urls.map((url, index) => (
            <div key={index}>
              <a href={url} style={{width:"100px",wordBreak: 'break-all'}}>{url}</a>
            </div>
          ));

          return {
            children: urlElements,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        } else {
          return {
            children: null,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        }
      },
    },
    {
      title: "案例描述",
      dataIndex: 'case_describe',
      ellipsis: true,
    }
  ];


  async function fetchDataEnv(searchValue: string) {
    console.log("首页搜索内容是: "+searchValue);
    const response = await request("/risk/risks/getMsgByCase",{
      method: "post",
      data:{
        "data": searchValue,
      }
    }).then(data=>{
      return data;
    })
    return response;
  }

  async function fetchDataPeo(searchValue: string) {
    console.log("首页搜索内容是: "+searchValue);
    const response = await request("/risk/peorisks/getMsgByCase",{
      method: "post",
      data:{
        "data": searchValue,
      }
    }).then(data=>{
      return data;
    })
    return response;
  }


  async function fetchDataMan(searchValue: string) {
    console.log("首页搜索内容是: "+searchValue);
    const response = await request("/risk/managerisks/getMsgByCase",{
      method: "post",
      data:{
        "data": searchValue,
      }
    }).then(data=>{
      return data;
    })
    return response;
  }
  const handleSearch = async (value:string) => {
    setLoading(true);
    // 根据搜索值从数据库中查询三张表的数据并更新状态
    // 示例代码：
     const resultsEnv = await fetchDataEnv(value);
     const results2 = await fetchDataPeo(value);
     const results3 = await fetchDataMan(value);
     setTable1Data(resultsEnv);
     setTable2Data(results2);
     setTable3Data(results3);
    setLoading(false);
  };
  useEffect(() => {
    handleSearch('');
  }, []);

  return (
    <Space direction="vertical" style={{ width: '100%' }}>
  <Input.Search
    placeholder="输入关键字搜索"
  enterButton="搜索"
  size="large"
  onSearch={handleSearch}
  />
  <Card title="环境设施风险" loading={loading}>
  <ProTable columns={columns1} dataSource={table1Data}  rowKey="id1" search={false} pagination={{pageSize: 5}}/>
    </Card>
    <Card title="人员行为风险" loading={loading}>
  <ProTable columns={columns2} dataSource={table2Data} rowKey="id2" search={false} pagination={{pageSize: 5}}/>
    </Card>
    <Card title="管理风险" loading={loading}>
  <ProTable columns={columns3} dataSource={table3Data} rowKey="id3" search={false} pagination={{pageSize: 5}}/>
    </Card>
    </Space>
);
};

export default HomeSearch;
