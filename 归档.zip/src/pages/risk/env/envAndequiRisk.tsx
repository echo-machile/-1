import React, { useState } from 'react';
import { Button, Modal, Form, message } from 'antd';
import { PlusOutlined } from '@ant-design/icons';
import RiskCategoryForm from './riskCate';
import RiskCategoryTable from './envRiskTable';

const App = () => {
  const [visible, setVisible] = useState(false);
  const [form] = Form.useForm();
  const [dataSource, setDataSource] = useState([]);

  const showModal = () => {
    setVisible(true);
  };

  const handleCancel = () => {
    setVisible(false);
  };

  const handleOk = () => {
    form
      .validateFields()
      .then((values) => {
        // 这里添加你的增删改查逻辑
        // 根据values.action进行相应的操作
        // 操作成功后，更新dataSource，并关闭对话框
        console.log(values);
        message.success('操作成功');
        setVisible(false);
      })
      .catch((errorInfo) => {
        console.log(errorInfo);
        message.error('操作失败');
      });
  };

  return (
    <div>
      <Button type="primary" icon={<PlusOutlined />} onClick={showModal}>
        新增风险类别
      </Button>
      <Modal
        title="新增风险类别"
        open={visible}
        onCancel={handleCancel}
        onOk={handleOk}
      >
        <RiskCategoryForm form={form} />
      </Modal>
      <RiskCategoryTable dataSource={dataSource} />
    </div>
  );
};
export default App;
