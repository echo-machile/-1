import React from 'react';
import { Form, Input, Select } from 'antd';

const { Option } = Select;

const RiskCategoryForm = ({ form }) => {
  return (
    <Form form={form} layout="vertical">
      <Form.Item
        name="name"
        label="风险类别名称"
        rules={[{ required: true, message: '请输入风险类别名称!' }]}
      >
        <Input placeholder="请输入风险类别名称" />
      </Form.Item>
      <Form.Item
        name="action"
        label="操作"
        rules={[{ required: true, message: '请选择操作!' }]}
      >
        <Select placeholder="请选择操作">
          <Option value="add">增加</Option>
          <Option value="delete">删除</Option>
          <Option value="update">更新</Option>
          <Option value="query">查询</Option>
        </Select>
      </Form.Item>
    </Form>
  );
};

export default RiskCategoryForm;
