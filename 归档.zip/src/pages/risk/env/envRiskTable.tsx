import React from 'react';
import { Table } from 'antd';

const RiskCategoryTable = ({ dataSource }) => {
  const columns = [
    {
      title: 'ID',
      dataIndex: 'id',
      key: 'id',
    },
    {
      title: '风险类别名称',
      dataIndex: 'name',
      key: 'name',
    },
  ];

  return (
    <Table dataSource={dataSource} columns={columns} rowKey="id" />
  );
};

export default RiskCategoryTable;
