import {addRisk, removeRule, rule,rulePeo, updateRule} from '@/services/ant-design-pro/api';
import {MehOutlined, PlusOutlined} from '@ant-design/icons';
import type { ActionType, ProColumns, ProDescriptionsItemProps } from '@ant-design/pro-components';
import {
  FooterToolbar,
  ModalForm,
  PageContainer,
  ProDescriptions, ProFormSelect,
  ProFormText,
  ProFormTextArea,
  ProTable,
} from '@ant-design/pro-components';
import {formatMessage, FormattedMessage, request, useIntl} from '@umijs/max';
import {Button, Drawer, Input, message, Select} from 'antd';
import React, {useEffect, useRef, useState} from 'react';
import type { FormValueType } from './components/UpdateForm';
import UpdateForm from './components/UpdateForm';
import {val} from "@umijs/utils/compiled/cheerio/lib/api/attributes";
const { Option } = Select;
import get, {post} from '../../utils/request';
import {ProForm, ProFormList} from "@ant-design/pro-form/lib";
import {ProFormField} from "@ant-design/pro-form";
/**
 * @en-US Add node
 * @zh-CN 添加节点
 * @param fields
 */
const handleAdd = async (fields) => {
  const hide = message.loading('正在添加');
  console.log(fields);
  try {
    await request("/risk/peorisks/add",{
      method:"post",
      data:{...fields}});
    hide();
    message.success('Added successfully');
    return true;
  } catch (error) {
    hide();
    message.error('Adding failed, please try again!');
    return false;
  }
};

/**
 * @en-US Update node
 * @zh-CN 更新节点
 *
 * @param fields
 */
const handleUpdate = async (fields: FormValueType) => {
  const hide = message.loading('Configuring');
  try {
    await updateRule({
      name: fields.name,
      desc: fields.desc,
      key: fields.key,
    });
    hide();

    message.success('Configuration is successful');
    return true;
  } catch (error) {
    hide();
    message.error('Configuration failed, please try again!');
    return false;
  }
};

/**
 *  Delete node
 * @zh-CN 删除节点
 *
 * @param selectedRows
 */
const handleRemove = async (selectedRows: API.RuleListItem[]) => {
  const hide = message.loading('正在删除');
  if (!selectedRows) return true;
  console.log({
    key: selectedRows.map((row) => row.id),
  })

  try {
    await request("/risk/peorisks/remove",{
      method:"post",
      data: {
        key: selectedRows.map((row) => row.id),
      }
    }
      );
    hide();
    message.success('成功删除!');
    return true;
  } catch (error) {
    hide();
    message.error('Delete failed, please try again');
    return false;
  }
};




const TableList: React.FC = () => {
  /**
   * @en-US Pop-up window of new window
   * @zh-CN 新建窗口的弹窗
   *  */
  const [createModalOpen, handleModalOpen] = useState<boolean>(false);
  const [siteModal, siteModalOpen] = useState<boolean>(false);
  const [siteAdd, siteAddSet] = useState<boolean>(true);
  const [siteDel, siteDelSet] = useState<boolean>(false);
  const [siteUpdate, siteUpdateSet] = useState<boolean>(false);
  const [siteDate,setSiteData] = useState([])
  const [selectedValue, setSelectedValue] = useState(1);
  /**
   * @en-US The pop-up window of the distribution update window
   * @zh-CN 分布更新窗口的弹窗
   * */
  const [updateModalOpen, handleUpdateModalOpen] = useState<boolean>(false);
  const [updateModalOpen2, handleUpdateModalOpenForRisk] = useState<boolean>(false);

  const [showDetail, setShowDetail] = useState<boolean>(false);

  const actionRef = useRef<ActionType>();
  const [currentRow, setCurrentRow] = useState<API.RuleListItem>();
  const [selectedRowsState, setSelectedRows] = useState<API.Risk[] | API.Riskr[]>([]);

  const [form] = ProForm.useForm();

  /**
   * @en-US International configuration
   * @zh-CN 国际化配置
   * */
  const intl = useIntl();

  useEffect(() => {
      request("/risk/site",{
        method:"get"
      }).then(data => {
        console.log(data);
        setSiteData(data);
      })
    },
    [siteAdd,siteDel,siteUpdate])
  const handleSiteSet = async (value)=>{

    if(siteAdd){
      post('/site/add',{"type":value.name}).then(data=>{
        console.log(data)
        siteModalOpen(false)
        setSelectedValue(1)
        if(data.data.code == 200){
          message.success("场地添加成功！")
        }

      })
    }else if(siteDel){
      request(`/risk/site/del/${selectedValue}`,{
        method:"get"
      }).then(data=>{
        console.log(data)
        siteModalOpen(false)
        setSelectedValue(1)
        if(data.code == 200){
          message.success("场地删除成功！")
        }

      })
    }else if(siteUpdate){
      request(`/risk/site/update`,{
        method:"post",
        data:{
          id: selectedValue,
          name: value.update
        }
      }).then(data=>{
        console.log(data)
        siteModalOpen(false)
        setSelectedValue(1)
        if(data.code == 200){
          message.success("场地更新成功！")
        }

      })
    }
  }

  const columns: ProColumns<API.Risk>[] = [
    {
      title: (
        <FormattedMessage
          id="pages.risk.id"
          defaultMessage="风险Id"
        />
      ),
      dataIndex: 'id',
      tip: '风险编号',
      render: (dom, entity) => {
        return (
          <a
            onClick={() => {
              setCurrentRow(entity);
              setShowDetail(true);
            }}
          >
            {dom}
          </a>
        );
      },
    },
    {
      title: <FormattedMessage id="pages.risk.site" defaultMessage="场所部位" />,
      dataIndex: 'location',
      valueType: 'textarea',
    },
    {
      title: <FormattedMessage id="pages.risk.site" defaultMessage="管理活动类型" />,
      dataIndex: 'manageActivityTypes',
      valueType: 'textarea',
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.equipment"
          defaultMessage="装备以及工具"
        />
      ),
      dataIndex: 'equipmentAndTools',
      sorter: true,
      hideInForm: true,
      // renderText: (val: string) =>
      //   `${val}${intl.formatMessage({
      //     id: 'pages.risk.equip',
      //     defaultMessage: '  ',
      //   })}`,
    },
    {
      title: <FormattedMessage id="pages.risk.energySource" defaultMessage="能量源" />,
      dataIndex: 'energySource',
      hideInForm: true,
      // valueEnum: {
      //   0: {
      //     text: (
      //       <FormattedMessage
      //         id="pages.searchTable.nameStatus.default"
      //         defaultMessage="Shut down"
      //       />
      //     ),
      //     status: 'Default',
      //   },
      //   1: {
      //     text: (
      //       <FormattedMessage id="pages.searchTable.nameStatus.running" defaultMessage="Running" />
      //     ),
      //     status: 'Processing',
      //   },
      //   2: {
      //     text: (
      //       <FormattedMessage id="pages.searchTable.nameStatus.online" defaultMessage="Online" />
      //     ),
      //     status: 'Success',
      //   },
      //   3: {
      //     text: (
      //       <FormattedMessage
      //         id="pages.searchTable.nameStatus.abnormal"
      //         defaultMessage="Abnormal"
      //       />
      //     ),
      //     status: 'Error',
      //   },
      // },
    },
    {
      title: (
        <FormattedMessage
          id="pages.risk.describe"
          defaultMessage="风险描述"
        />
      ),
      sorter: true,
      dataIndex: 'riskDescription',
      //valueType: 'dateTime',
      // renderFormItem: (item, { defaultRender, ...rest }, form) => {
      //   const status = form.getFieldValue('status');
      //   if (`${status}` === '0') {
      //     return false;
      //   }
      //   if (`${status}` === '3') {
      //     return (
      //       <Input
      //         {...rest}
      //         placeholder={intl.formatMessage({
      //           id: 'pages.searchTable.exception',
      //           defaultMessage: 'Please enter the reason for the exception!',
      //         })}
      //       />
      //     );
      //   }
      //   return defaultRender(item);
      // },
    },
    {
      title: <FormattedMessage id="pages.risk.accident" defaultMessage="事故类型" />,
      dataIndex: 'accidentType',
      //valueType: 'option',
      // render: (_, record) => [
      //   <a
      //     key="config"
      //     onClick={() => {
      //       handleUpdateModalOpen(true);
      //       setCurrentRow(record);
      //     }}
      //   >
      //     <FormattedMessage id="pages.searchTable.config" defaultMessage="Configuration" />
      //   </a>,
      //   <a key="subscribeAlert" href="https://procomponents.ant.design/">
      //     <FormattedMessage
      //       id="pages.searchTable.subscribeAlert"
      //       defaultMessage="Subscribe to alerts"
      //     />
      //   </a>,
      // ],
    },
    {
      title: "L",
      dataIndex: 'l',
    },
    {
      title: "E",
      dataIndex: 'e',
    },{
      title: "C",
      dataIndex: 'c',
    },
    {
      title: "D",
      dataIndex: 'd',
      render: (text, record) => {
        let color;
        if(record.riskLevel == '三级'){
          color = 'yellow';
        }else if(record.riskLevel == '二级'){
          color = 'orange';
        }else if(record.riskLevel == '一级'){
          color = 'red';
        }else if(record.riskLevel == '四级'){
          color = 'blue';
        }
        return {
          children: text,
          props: {
            style: {
              backgroundColor: color,
            },
          },
        };
      },
    },
    {
      title: "风险等级",
      dataIndex: 'riskLevel',
    },
    {
      title: "工程技术措施",
      dataIndex: 'engineeringTechnicalMeasures',
    },
    {
      title: "安全管理措施",
      dataIndex: 'safetyManagementMeasures',
    },
    {
      title: "个人培训措施",
      dataIndex: 'personnelTrainingMeasures',
    }
    ,
    {
      title: "个人防护措施",
      dataIndex: 'individualProtection',
    },
    {
      title: "应急处理措施",
      dataIndex: 'emergencyResponseMeasures',
    },
    {
      title: "责任部门",
      dataIndex: 'responsibleDepartment',
    },
    {
      title: "责任人",
      dataIndex: 'personLiable',
    },
    {
      title: "案例链接",
      dataIndex: 'link',
      width: "100px",
      render: (text, record) => {

        if (text) {
          const urls = text.split('\n');
          const urlElements = urls.map((url, index) => (
            <div key={index}>
              <a href={url} style={{width:"100px",wordBreak: 'break-all'}}>{url}</a>
            </div>
          ));

          return {
            children: urlElements,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        } else {
          return {
            children: null,
            props: {
              style: {
                //backgroundColor: color,
              },
            },
          };
        }
      },
    },
    {
      title: "案例描述",
      dataIndex: 'caseDescribe',
      ellipsis: true,
    }
  ];


  const handleSelectChange=(value:string)=>{
    console.log("选择的是"+value);
    setSelectedValue(value);
  }
  const onChange = (value: string) => {
    console.log(`selected ${value}`);
    if(value && value == 'add'){
      siteAddSet(true);
      siteDelSet(false);
      siteUpdateSet(false);
    }else if(value && value == "delete"){
      siteDelSet(true)
      siteAddSet(false);
      siteUpdateSet(false);
    }else if(value && value == "update"){
      siteDelSet(false)
      siteAddSet(false);
      siteUpdateSet(true);
    }
  };

  const handleCalculation = () => {
    const l = form.getFieldValue('L');
    const e = form.getFieldValue('E');
    const c = form.getFieldValue('C');
    console.log(l,e,c);
    const lr = form.getFieldValue('Lr');
    const er = form.getFieldValue('Er');
    const cr = form.getFieldValue('Cr');
    console.log(lr,er,cr);
    if ((l && e && c)|| (lr && er && cr)) {
      const result = l * e * c;
      const resultr = lr * er * cr;
      form.setFieldsValue({ D: result });
      form.setFieldsValue({ Dr: resultr });
    } else {
      form.setFieldsValue({ D: '' });
    }
  };

  async function handleUpdateRisk(value:API.Riskr) {
    const hide = message.loading('Configuring');
    console.log("数据123: "+value.riskLevelr);
    try {
      await request("/risk/peorisks/update",{
        method: "post",
        data: value,
      })
      hide();
      message.success('Configuration is successful');
      return true;
    } catch (error) {
      hide();
      message.error('Configuration failed, please try again!');
      return false;
    }
  }

  return (
    <PageContainer>
      <ProTable
        headerTitle={formatMessage({
          id: '环境设施类风险',
          defaultMessage: '环境设施类风险',
        })}
        actionRef={actionRef}
        rowKey={record => {return record.id}}
        search={{
          labelWidth: 120,
        }}
        bordered={true}
        toolBarRender={() => [
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              handleModalOpen(true);
            }}
          >
            <PlusOutlined /> <FormattedMessage id="pages.searchTable.new" defaultMessage="New" />
          </Button>,
          <Button
            type="primary"
            key="primary"
            onClick={() => {
              siteModalOpen(true);
            }}
          >
            <MehOutlined /> <FormattedMessage id="pages.site.new" defaultMessage="场所部位" />
          </Button>,
        ]}
        request={rulePeo}
        columns={columns}
        rowSelection={{
          onChange: (_, selectedRows) => {
            setSelectedRows(selectedRows);
          },
        }}
      />
      {selectedRowsState?.length > 0 && (
        <FooterToolbar
          extra={
            <div>
              <FormattedMessage id="pages.searchTable.chosen" defaultMessage="Chosen" />{' '}
              <a style={{ fontWeight: 600 }}>{selectedRowsState.length}</a>{' '}
              <FormattedMessage id="pages.searchTable.item" defaultMessage="项" />
              &nbsp;&nbsp;
              <span>
                <FormattedMessage
                  id="pages.searchTable.totalServiceCalls"
                  defaultMessage="Total number of service calls"
                />{' '}
                {selectedRowsState.reduce((pre, item) => pre + item.callNo!, 0)}{' '}
                <FormattedMessage id="pages.searchTable.tenThousand" defaultMessage="万" />
              </span>
            </div>
          }
        >
          <Button
            onClick={async () => {
              await handleRemove(selectedRowsState);
              setSelectedRows([]);
              actionRef.current?.reloadAndRest?.();
            }}
          >
            <FormattedMessage
              id="pages.searchTable.batchDeletion"
              defaultMessage="Batch deletion"
            />
          </Button>
          <Button type="primary" onClick={async () => {
            //handleUpdateModalOpen(true);
            handleUpdateModalOpenForRisk(true);
            console.log("选中行的内容: "+selectedRowsState);
            //setSelectedRows([]);
            //actionRef.current?.reloadAndRest?.();
          }}>
            <FormattedMessage
              id="pages.searchTable.batchApproval"
              defaultMessage="Batch approval"
            />
          </Button>
        </FooterToolbar>
      )}
      <ModalForm
        title={formatMessage({
          id: '风险信息',
          defaultMessage: '设备设施风险添加',
        })}
        form={form}
        width="400px"
        open={createModalOpen}
        onOpenChange={handleModalOpen}
        onFinish={async (value) => {
          value.location = selectedValue;
          const success = await handleAdd(value);
          if (success) {
            handleModalOpen(false);
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
      >
        <ProFormSelect
          width="md"
          name="location"
          label="场所部位:"
          allowClear
        >
          <Select value={selectedValue} onChange={handleSelectChange} style={{width: "150px"}}>
            {siteDate.map((option) => (
              <Option key={option.id} value={option.id}>
                {option.pos}
              </Option>
            ))
            }
          </Select>
        </ProFormSelect>
        <ProFormText
          width="md"
          name="manageActivityTypes"
          label="管理活动类型:"
        />
        <ProFormText
          width="md"
          name="equipmentAndTools"
          label="装备以及工具:"
        />
        <ProFormText
          width="md"
          name="energySource"
          label="能量源头:"
        />
        <ProFormText
        width="md"
        name="riskDescription"
        label="风险描述:"

      /><ProFormText
        width="md"
        name="accidentType"
        label="事故类型:"
      />
        <ProForm.Item name="L" label="L:">
        <Input onChange={handleCalculation} />
      </ProForm.Item>
        <ProForm.Item name="E" label="E:">
          <Input onChange={handleCalculation} />
        </ProForm.Item>
        <ProForm.Item name="C" label="C:">
          <Input  onChange={handleCalculation} />
        </ProForm.Item>
        <ProForm.Item name="D" label="D:">
          <Input readOnly />
        </ProForm.Item>
        <ProFormText
          width="md"
          name="riskLevel"
          label="风险等级:"
        />
        <ProFormText
        width="md"
        name="engineeringTechnicalMeasures"
        label="工程技术措施:"
      /><ProFormText
        width="md"
        name="safetyManagementMeasures"
        label="安全管理措施:"
      /><ProFormText
        width="md"
        name="personnelTrainingMeasures"
        label="个人培训措施:"
      /><ProFormText
        width="md"
        name="individualProtection"
        label="个人防护措施:"
      /><ProFormText
        width="md"
        name="emergencyResponseMeasures"
        label="应急处理措施:"
      /><ProFormText
        width="md"
        name="responsibleDepartment"
        label="责任部门:"
      /><ProFormText
        width="md"
        name="personLiable"
        label="责任人:"
      /><ProFormTextArea
        width="md"
        name="link"
        label="案例链接:"
      /><ProFormTextArea
        width="md"
        name="caseDescribe"
        label="案例描述:"
      />

      </ModalForm>

      <ModalForm
        title={formatMessage({
          id: '风险信息',
          defaultMessage: '设备设施风险修改',
        })}
        name="iiid"
        form={form}
        width="400px"
        open={updateModalOpen2}
        onOpenChange={handleUpdateModalOpenForRisk}
        onFinish={async (value) => {
          value.locationr = selectedValue;
          value.id = selectedRowsState[0].id;
          value.L = selectedRowsState[0].l;
          value.E = selectedRowsState[0].e;
          value.C = selectedRowsState[0].c;
          value.D = selectedRowsState[0].d;
          const success = await handleUpdateRisk(value);
          if (success) {
            handleUpdateModalOpenForRisk(false)
            setSelectedRows([]);
            actionRef.current?.reloadAndRest?.();
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
      >
        <ProFormSelect
          width="md"
          name="locationr"
          label="场所部位:"
          allowClear
        >
          <Select value={selectedValue} onChange={handleSelectChange} style={{width: "150px"}}>
            {siteDate.map((option) => (
              <Option key={option.id} value={option.id}>
                {option.pos}
              </Option>
            ))
            }
          </Select>
        </ProFormSelect>

        <ProFormText
          width="md"
          name="manageActivityTypesr"
          label="管理活动类型:"
          initialValue={selectedRowsState[0]?.manageActivityTypes}
        />
        <ProFormText
          width="md"
          name="equipmentAndToolsr"
          label="装备以及工具:"
          initialValue={selectedRowsState[0]?.equipmentAndTools}
        />
        <ProFormText
          width="md"
          name="energySourcer"
          label="能量源头:"
          initialValue={selectedRowsState[0]?.energySource}
        />
        <ProFormText
          width="md"
          name="riskDescriptionr"
          label="风险描述:"
          initialValue={selectedRowsState[0]?.riskDescription}
        /><ProFormText
        width="md"
        name="accidentTyper"
        label="事故类型:"
        initialValue={selectedRowsState[0]?.accidentType}
      />
        <ProForm.Item name="Lr" label="L:">
          <Input onChange={handleCalculation} defaultValue={selectedRowsState[0]?.l}/>
        </ProForm.Item>
        <ProForm.Item name="Er" label="E:">
          <Input onChange={handleCalculation} defaultValue={selectedRowsState[0]?.e}/>
        </ProForm.Item>
        <ProForm.Item name="Cr" label="C:" >
          <Input  onChange={handleCalculation} defaultValue={selectedRowsState[0]?.c}/>
        </ProForm.Item>
        <ProForm.Item name="Dr" label="D:" >
          <Input readOnly defaultValue={selectedRowsState[0]?.d}/>
        </ProForm.Item>
        <ProFormText
          width="md"
          name="riskLevelr"
          label="风险等级:"
          initialValue={selectedRowsState[0]?.riskLevel}
        />
        <ProFormText
          width="md"
          name="engineeringTechnicalMeasuresr"
          label="工程技术措施:"
          initialValue={selectedRowsState[0]?.engineeringTechnicalMeasures}
        /><ProFormText
        width="md"
        name="safetyManagementMeasuresr"
        label="安全管理措施:"
        initialValue={selectedRowsState[0]?.safetyManagementMeasures}
      /><ProFormText
        width="md"
        name="personnelTrainingMeasuresr"
        label="个人培训措施:"
        initialValue={selectedRowsState[0]?.personnelTrainingMeasures}
      /><ProFormText
        width="md"
        name="individualProtectionr"
        label="个人防护措施:"
        initialValue={selectedRowsState[0]?.individualProtection}
      /><ProFormText
        width="md"
        name="emergencyResponseMeasuresr"
        label="应急处理措施:"
        initialValue={selectedRowsState[0]?.emergencyResponseMeasures}
      /><ProFormText
        width="md"
        name="responsibleDepartmentr"
        label="责任部门:"
        initialValue={selectedRowsState[0]?.responsibleDepartment}
      /><ProFormText
        width="md"
        name="personLiabler"
        label="责任人:"
        initialValue={selectedRowsState[0]?.personLiable}
      /><ProFormTextArea
        width="md"
        name="linkr"
        label="案例链接:"
        initialValue={selectedRowsState[0]?.link}
      /><ProFormTextArea
        width="md"
        name="caseDescriber"
        label="案例描述:"
        initialValue={selectedRowsState[0]?.caseDescribe}
      />

      </ModalForm>
      <ModalForm
        title={formatMessage({
          id: '场所部位',
          defaultMessage: '场所部位设置',
        })}
        width="400px"
        open={siteModal}
        initialValues={selectedRowsState.id}
        onOpenChange={siteModalOpen}
        onFinish={async (value) => {
          const success = await handleSiteSet(value);
          if (success) {
            handleModalOpen(false);
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
      >
        <Select placeholder="请选择操作" defaultValue={siteAdd?"add":null} onChange={onChange} style={{marginBottom:10,width:"93%"}}>
          <Option value="add">增加</Option>
          <Option value="delete">删除</Option>
          <Option value="update">更新</Option>
        </Select>
        {
          siteAdd && <ProFormText
            rules={[
              {
                required: true,
                message: (
                  <FormattedMessage
                    id="pages.risk.ruleName"
                    defaultMessage="场所部位是必需填写的"
                  />
                ),
              },
            ]}
            width="md"
            name="name"

          />
        }
        {
          siteDel &&<Select value={selectedValue} onChange={handleSelectChange}>
            {siteDate.map((option) => (
              <Option key={option.id} value={option.id}>
                {option.pos}
              </Option>
            ))

            }
          </Select>
        }
        {
          siteUpdate && <Select value={selectedValue} style={{marginBottom:10,width:150}} onChange={handleSelectChange}>
            {siteDate.map((option) => (
              <Option key={option.id} value={option.id}>
                {option.pos}
              </Option>
            ))

            }
          </Select>
        }
        {
          siteUpdate && <ProFormText
            rules={[
              {
                required: true,
                message: (
                  <FormattedMessage
                    id="pages.risk.ruleName"
                    defaultMessage="场所部位是必需填写的"
                  />
                ),
              },
            ]}
            width="md"
            name="update"

          />
        }


      </ModalForm>
      <UpdateForm
        onSubmit={async (value) => {
          const success = await handleUpdate(value);
          if (success) {
            handleUpdateModalOpen(false);
            setCurrentRow(undefined);
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
        onCancel={() => {
          handleUpdateModalOpen(false);
          if (!showDetail) {
            setCurrentRow(undefined);
          }
        }}
        updateModalOpen={updateModalOpen}
        values={currentRow || {}}
      />

      <Drawer
        width={600}
        open={showDetail}
        onClose={() => {
          setCurrentRow(undefined);
          setShowDetail(false);
        }}
        closable={false}
      >
        {currentRow?.name && (
          <ProDescriptions<API.RuleListItem>
            column={2}
            title={currentRow?.name}
            request={async () => ({
              data: currentRow || {},
            })}
            params={{
              id: currentRow?.name,
            }}
            columns={columns as ProDescriptionsItemProps<API.RuleListItem>[]}
          />
        )}
      </Drawer>
    </PageContainer>
  );
};

export default TableList;
