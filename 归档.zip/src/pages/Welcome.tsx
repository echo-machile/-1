// 引入React和所需的Ant Design组件
import React from 'react';
import { Card, Typography, Row, Col, Space } from 'antd';
import { SmileTwoTone } from '@ant-design/icons';
import styles from './Welcome.less';
import handleSearch from "@/components/welcome/HandleSearch";
import HandleSearch from "@/components/welcome/HandleSearch";

const { Title, Text } = Typography;

const Welcome: React.FC = () => {
  return (
    <div className={styles.container}>
      {/*<Row justify="center" align="middle" style={{ minHeight: '100vh' }}>*/}
      {/*  <Col>*/}
      {/*    <Card className={styles.card}>*/}
      {/*      <Space direction="vertical" size="middle">*/}
      {/*        <SmileTwoTone className={styles.icon} twoToneColor="#1890ff" />*/}
      {/*        <Title level={2}>欢迎使用建筑施工过程风险系统</Title>*/}
      {/*        <Text>*/}
      {/*          在这里，您可以管理和监控与建筑施工过程相关的各种风险，确保施工项目的顺利进行。请使用左侧菜单栏开始您的操作。*/}
      {/*        </Text>*/}
      {/*      </Space>*/}
      {/*    </Card>*/}
      {/*  </Col>*/}
      {/*</Row>*/}
      <HandleSearch></HandleSearch>
    </div>
  );
};

export default Welcome;
